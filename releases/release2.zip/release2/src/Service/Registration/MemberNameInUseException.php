<?php


namespace App\Service\Registration;


class MemberNameInUseException extends \RuntimeException
{

}
