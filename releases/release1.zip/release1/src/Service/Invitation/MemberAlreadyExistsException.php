<?php


namespace App\Service\Invitation;


class MemberAlreadyExistsException extends \RuntimeException
{

}
