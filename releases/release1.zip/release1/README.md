# Dépôt servant pour le développement du projet de l'équipe 1 du groupe 1.

Le dépôt de release peut être consulté à cette addresse : [Dépôt de release](https://github.com/ArthurPeyrichou/CDP_Gr1_Eq1_Release).