<?php


namespace App\EntityException;


class InvalidStatusTransitionException extends \RuntimeException
{

}
