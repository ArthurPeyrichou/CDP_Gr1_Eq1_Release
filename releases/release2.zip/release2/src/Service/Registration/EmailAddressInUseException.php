<?php


namespace App\Service\Registration;


class EmailAddressInUseException extends \RuntimeException
{

}
