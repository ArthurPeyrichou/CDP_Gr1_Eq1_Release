<?php


namespace App\Service\Invitation;


class MemberIsOwnerException extends \RuntimeException
{

}
