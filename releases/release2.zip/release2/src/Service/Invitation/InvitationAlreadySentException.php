<?php


namespace App\Service\Invitation;


class InvitationAlreadySentException extends \RuntimeException
{

}
